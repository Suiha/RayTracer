#include "ofApp.h"

void ofApp::setup() {
	printf("Setup\n");
	ofSetBackgroundColor(ofColor::black);

	// camera setup
	mainCam.setDistance(20);
	mainCam.setNearClip(.1);
	sideCam.setPosition(glm::vec3(50, 0, 0));
	sideCam.lookAt(glm::vec3(0, 0, 0));
	sideCam.setNearClip(.1);
	previewCam.setPosition(renderCam.position);
	previewCam.setNearClip(.1);
	renderCam.position = mainCam.getPosition();
	theCam = &mainCam;

	// create scene
	scene.push_back(new Sphere(glm::vec3(-1, 0, 5), 1.0, ofColor::lightYellow));
	scene.push_back(new Sphere(glm::vec3(0.5, 0, 0), 2.0, ofColor::lightBlue));
	scene.push_back(new Sphere(glm::vec3(0, 2, -5), 4.0, ofColor::mediumPurple));

	// plane: origin point, normal vector, color
	scene.push_back(new Plane(glm::vec3(0, -2, 0), glm::vec3(0, 1, 0), ofColor::darkGray));
}

void ofApp::update() {}

void ofApp::draw() {
	theCam->begin();

	// draw scene objects
	ofFill();
	ofPushMatrix();
	for (auto obj : scene) {
		obj->draw();
	}
	ofPopMatrix();
	ofNoFill();

	// draw render view as white box
	ofPushMatrix();
	ofNoFill();
	ofSetColor(ofColor::white);
	renderCam.view.draw();
	ofPopMatrix();

	ofSetColor(ofColor::lightGray);
	mainCam.draw();
	theCam->end();

	// allocate space for image
	image.allocate(600, 400, OF_IMAGE_COLOR);

}

void ofApp::keyPressed(int key) {
	switch (key) {
	case 'r':
		rayTrace();
		break;
	case OF_KEY_F1:
		theCam = &mainCam;
		break;
	case OF_KEY_F2:
		// look at render cam
		theCam = &previewCam;
		break;
	case OF_KEY_F3:
		theCam = &sideCam;
		break;
	default:
		break;
	}
}

void ofApp::keyReleased(int key) {}
void ofApp::mouseMoved(int x, int y) {}
void ofApp::mouseDragged(int x, int y, int button) {}
void ofApp::mousePressed(int x, int y, int button) {}
void ofApp::mouseReleased(int x, int y, int button) {}
void ofApp::mouseEntered(int x, int y) {}
void ofApp::mouseExited(int x, int y) {}
void ofApp::windowResized(int w, int h) {}
void ofApp::dragEvent(ofDragInfo dragInfo) {}
void ofApp::gotMessage(ofMessage msg) {}

// main ray trace loop, called by 'r' button
void ofApp::rayTrace() {
	//printf("rayTrace called\n");

	// image resolution in x, y
	auto Nx = image.getWidth();
	auto Ny = image.getHeight();

	for (int i = 0; i < Nx; i++) {
		for (int j = 0; j < Ny; j++) {
			// to keep track of rayTrace progress
			//cout << i << ", " << j << endl;

			auto u = (i + 0.5) / Nx;
			auto v = (j + 0.5) / Ny;

			Ray ray = renderCam.getRay(u, v);
			bool hit = false;
			auto distance = std::numeric_limits<float>::infinity();
			SceneObject* closestObject = NULL;

			for (SceneObject* object : scene) {
				// check intersection and its distance from camera
				if (object->intersect(ray, glm::vec3(u, v, 0), glm::vec3(0, 0, 1))) {
					
					auto camPos = renderCam.position;
					auto intersectDistance = glm::length(ray.p + (ray.d * glm::length(glm::vec3(u, v, 0) - camPos)));
					if (intersectDistance < distance) {
						closestObject = object;
						distance = intersectDistance;
					}
				}
				if (closestObject) hit = true;
			}

			if (hit) {
				image.setColor(i, j, closestObject->diffuseColor);
			}
			else {
				image.setColor(i, j, ofGetBackgroundColor());
			}
			
			image.update();
		}
	}
	//printf("rayTrace done\n");

	// image is upside down, flip vertically
	image.mirror(true, false);
	image.save("/images/render.png");
}

void ofApp::drawGrid() {}
void ofApp::drawAxis(glm::vec3 position) {}

// Intersect Ray with Plane  (wrapper on glm::intersect*
//
bool Plane::intersect(const Ray& ray, glm::vec3& point, glm::vec3& normalAtIntersect) {
	float dist;
	bool hit = glm::intersectRayPlane(ray.p, ray.d, position, this->normal, dist);
	if (hit) {
		Ray r = ray;
		point = r.evalPoint(dist);
	}
	return (hit);
}


// Convert (u, v) to (x, y, z) 
// We assume u,v is in [0, 1]
//
glm::vec3 ViewPlane::toWorld(float u, float v) {
	float w = width();
	float h = height();
	return (glm::vec3((u * w) + min.x, (v * h) + min.y, position.z));
}

// Get a ray from the current camera position to the (u, v) position on
// the ViewPlane
//
Ray RenderCam::getRay(float u, float v) {
	glm::vec3 pointOnPlane = view.toWorld(u, v);
	return(Ray(position, glm::normalize(pointOnPlane - position)));
}

void RenderCam::drawFrustum() {

}
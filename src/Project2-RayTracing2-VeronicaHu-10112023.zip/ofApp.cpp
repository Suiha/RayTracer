#include "ofApp.h"

void ofApp::setup() {
	printf("Setup\n");
	ofSetBackgroundColor(ofColor::black);

	// camera setup
	mainCam.setDistance(20);
	mainCam.setNearClip(.1);
	sideCam.setPosition(glm::vec3(50, 0, 0));
	sideCam.lookAt(glm::vec3(0, 0, 0));
	sideCam.setNearClip(.1);
	previewCam.setPosition(renderCam.position);
	previewCam.setNearClip(.1);
	renderCam.position = mainCam.getPosition();
	theCam = &mainCam;


	// create scene
	scene.push_back(new Sphere(glm::vec3(2, 1, -5), 2.0, ofColor::mediumPurple));
	scene.push_back(new Sphere(glm::vec3(0, 0, -2), 2.0, ofColor::green));
	scene.push_back(new Sphere(glm::vec3(-2.5, 0, 0), 1.0, ofColor::pink));

	// plane: origin point, normal vector, color
	//scene.push_back(new Plane(glm::vec3(0, 0, -50), glm::vec3(0, 0, 1), ofColor::darkGray));	// vertical plane
	scene.push_back(new Plane(glm::vec3(0, -2, 0), glm::vec3(0, 1, 0), ofColor::sandyBrown));	// horizontal plane
	
	// lights
	addLight(new PointLight(glm::vec3(3, 30, 0), 400));
	addLight(new PointLight(glm::vec3(-3, 20, 0), 200));
	addLight(new PointLight(glm::vec3(4, 30, 0)));
	ambientLight->intensity = 0.08;


	// gui
	gui.setup("RayTrace Settings");
	gui.add(lightIntensity.set("Light Intensities", 100, 10, 900));
	shading.setName("Shading Type");
	shading.add(lambertShading.set("Lambert Shading", false));
	shading.add(phongShading.set("Phong Shading", false));

	phongSettings.setName("Phong Settings");
	phongSettings.add(phongPower.set("Phong p value", 10, 10, 100));


	gui.add(shading);
	gui.add(phongSettings);

	// allocate space for image
	image.allocate(imageWidth, imageHeight, OF_IMAGE_COLOR);
}

void ofApp::update() {
	if (bSetLight) {
		for (auto light : lights) {
			light->intensity = lightIntensity;
		}
	}
}

void ofApp::draw() {
	ofEnableDepthTest();
	theCam->begin();

	// draw scene objects
	ofFill();
	ofPushMatrix();
	for (auto obj : scene) {
		obj->draw();
	}
	for (auto l : lights) {
		l->draw();
	}
	ofPopMatrix();
	ofNoFill();

	// draw render view as white box
	ofPushMatrix();
	ofNoFill();
	ofSetColor(ofColor::white);
	renderCam.view.draw();
	ofPopMatrix();

	ofSetColor(ofColor::lightGray);
	mainCam.draw();
	theCam->end();

	ofDisableDepthTest();

	if (!bHide) gui.draw();

	// rendered image
	if (bRendered) {
		image.draw((ofGetWindowWidth() / 2) - (imageWidth / 2), (ofGetWindowHeight() / 2) - (imageHeight / 2), imageWidth, imageHeight);
	}
}

void ofApp::keyPressed(int key) {
	switch (key) {
	case 'h':
		// show/hide gui
		bHide = !bHide;
		break;
	case 'i':
		// show/hide rendered image
		bRendered = !bRendered;
		break;
	case 'r':
		// render image with raytracing
		rayTrace();
		break;
	case 'l':
		bSetLight = !bSetLight;
		break;
	case OF_KEY_F1:
		theCam = &mainCam;
		break;
	case OF_KEY_F2:
		// look at render cam
		theCam = &previewCam;
		break;
	case OF_KEY_F3:
		theCam = &sideCam;
		break;
	default:
		break;
	}
}

void ofApp::keyReleased(int key) {}
void ofApp::mouseMoved(int x, int y) {}
void ofApp::mouseDragged(int x, int y, int button) {}
void ofApp::mousePressed(int x, int y, int button) {}
void ofApp::mouseReleased(int x, int y, int button) {}
void ofApp::mouseEntered(int x, int y) {}
void ofApp::mouseExited(int x, int y) {}
void ofApp::windowResized(int w, int h) {}
void ofApp::dragEvent(ofDragInfo dragInfo) {}
void ofApp::gotMessage(ofMessage msg) {}

// main ray trace loop, called by 'r' button
void ofApp::rayTrace() {
	printf("rayTrace called\n");

	// image resolution in x, y
	auto Nx = image.getWidth();
	auto Ny = image.getHeight();

	for (int i = 0; i < Nx; i++) {
		for (int j = 0; j < Ny; j++) {

			auto u = (i + 0.5) / Nx;
			auto v = (j + 0.5) / Ny;
			glm::vec3 point = glm::vec3(u, v, 0);

			Ray ray = renderCam.getRay(u, v);
			bool hit = false;
			auto distance = std::numeric_limits<float>::infinity();
			SceneObject* closestObject = NULL;

			for (SceneObject* object : scene) {
				// check intersection and its distance from camera
				if (object->intersect(ray, point, glm::vec3(0, 0, 1))) {
					auto camPos = renderCam.position;
					auto intersectDistance = glm::length(ray.p - point);
					if (intersectDistance < distance) {
						closestObject = object;
						distance = intersectDistance;
					}
				}
				if (closestObject) hit = true;
			}

			if (hit) {
				glm::vec3 normal = closestObject->getNormal(point);
				ofColor color = shade(point, normal, closestObject->diffuseColor, (SceneObject*)closestObject);
				image.setColor(i, j, color);
			}
			else {
				image.setColor(i, j, ofGetBackgroundColor());
			}
		}
	}
	image.update();

	// image is upside down, flip vertically
	image.mirror(true, false);
	image.save("/images/render3.png");
	bRendered = true;

	printf("rayTrace done\n");
}

// general shading function
ofColor ofApp::shade(const glm::vec3& p, const glm::vec3& norm, const ofColor diffuse, SceneObject* obj)
{
	ofColor result = ambientLight->intensity * diffuse;
	glm::vec3 point = p;
	for (auto light : lights) {

		Ray shadowRay = Ray(point, glm::normalize(light->position - p));
		shadowRay.p += 0.01 * shadowRay.d;
		if (!obj->intersect(shadowRay, point, glm::normalize(norm))) {

			// render with no shading
			if (!lambertShading && !phongShading) {
				result += diffuse;
				break;
			}

			if (lambertShading) {
				result += lambert(point, norm, diffuse, (PointLight*) light);
			}

			if (phongShading) {
				result += phong(point, norm, diffuse, ofColor::white, phongPower, (PointLight*) light);
			}

			result += shadows(shadowRay, point, norm, (PointLight*)light);
		}
	}
	return result;
}

// lambert shading
ofColor ofApp::lambert(const glm::vec3& p, const glm::vec3& norm, const ofColor diffuse, PointLight* light) {
	// calculate intensity of light with respect to distance
	auto distance = glm::length(light->position - p);
	auto illumination = light->intensity / (distance * distance);

	// lambert formula
	glm::vec3 lightDirection = glm::normalize(light->position - p);
	auto lambertCalc = glm::max(glm::dot(norm, lightDirection), 0.0f);

	return diffuse * illumination * lambertCalc;
}

// phong shading (lambert + specular)
ofColor ofApp::phong(const glm::vec3& p, const glm::vec3& norm,
	const ofColor diffuse, const ofColor specular, float power, PointLight* light) {
	// calculate intensity of light with respect to distance
	auto distance = glm::length(light->position - p);
	auto illumination = light->intensity / (distance * distance);

	// lambert formula
	glm::vec3 lightDirection = glm::normalize(light->position - p);
	auto lambertCalc = glm::max(glm::dot(norm, lightDirection), 0.0f);

	// specular formula
	glm::vec3 viewDirection = glm::normalize(renderCam.position - p);
	glm::vec3 reflection = glm::reflect(-lightDirection, norm);
	//auto h = glm::normalize(viewDirection * lightDirection);
	//auto specularCalc = glm::pow(glm::max(glm::dot(norm, h), 0.0f), power);
	auto specularCalc = glm::pow(glm::max(glm::dot(reflection, viewDirection), 0.0f), power);

	return (diffuse * lambertCalc + specular * specularCalc * illumination);
}

ofColor ofApp::shadows(Ray r, const glm::vec3& p, const glm::vec3& norm, PointLight* light) {
	bool bBlocked = false;

	// check if any object is between current point (p) and ray origin
	for (auto obj : scene) {
		glm::vec3 intersectionPoint;
		glm::vec3 intersectionNorm;

		if (obj->intersect(r, intersectionPoint, intersectionNorm)) {
			auto distance = glm::distance(r.p, intersectionPoint);
			if (distance > 0 && distance < glm::distance(r.p, p)) {
				bBlocked = true;
				break;
			}
		}
	}

	auto distance = glm::length(light->position - p);
	auto illumination = light->intensity / (distance * distance);
	return (bBlocked) ? ofColor::black * illumination : ofColor(0, 0, 0, 0);
}

void ofApp::drawGrid() {}
void ofApp::drawAxis(glm::vec3 position) {}

// Intersect Ray with Plane  (wrapper on glm::intersect*)
bool Plane::intersect(const Ray& ray, glm::vec3& point, glm::vec3& normalAtIntersect) {
	float dist;
	bool insidePlane = false;
	bool hit = glm::intersectRayPlane(ray.p, ray.d, position, this->normal, dist);
	if (hit) {
		Ray r = ray;
		point = r.evalPoint(dist);
		normalAtIntersect = this->normal;
		glm::vec2 xrange = glm::vec2(position.x - width / 2, position.x + width / 2);
		glm::vec2 yrange = glm::vec2(position.y - width / 2, position.y + width / 2);
		glm::vec2 zrange = glm::vec2(position.z - height / 2, position.z + height / 2);

		// horizontal
		if (normal == glm::vec3(0, 1, 0) || normal == glm::vec3(0, -1, 0)) {
			if (point.x < xrange[1] && point.x > xrange[0] && point.z < zrange[1] && point.z > zrange[0]) {
				insidePlane = true;
			}
		}
		// front or back
		else if (normal == glm::vec3(0, 0, 1) || normal == glm::vec3(0, 0, -1)) {
			if (point.x < xrange[1] && point.x > xrange[0] && point.y < yrange[1] && point.y > yrange[0]) {
				insidePlane = true;
			}
		}
		// left or right
		else if (normal == glm::vec3(1, 0, 0) || normal == glm::vec3(-1, 0, 0)) {
			if (point.y < yrange[1] && point.y > yrange[0] && point.z < zrange[1] && point.z > zrange[0]) {
				insidePlane = true;
			}
		}
	}
	return insidePlane;
}


// Convert (u, v) to (x, y, z) 
// We assume u,v is in [0, 1]
glm::vec3 ViewPlane::toWorld(float u, float v) {
	float w = width();
	float h = height();
	return (glm::vec3((u * w) + min.x, (v * h) + min.y, position.z));
}

// Get a ray from the current camera position to the (u, v) position on the ViewPlane
Ray RenderCam::getRay(float u, float v) {
	glm::vec3 pointOnPlane = view.toWorld(u, v);
	return(Ray(position, glm::normalize(pointOnPlane - position)));
}

void RenderCam::drawFrustum() {

}